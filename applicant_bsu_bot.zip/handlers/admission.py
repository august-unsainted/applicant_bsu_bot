from aiogram import Router, F
from aiogram.types import CallbackQuery

from utils.generate_kb import generate_kb
from utils.images import images
from utils.messages import messages

router = Router()


kb = generate_kb(
    'start',
    ['Расписание приёма и контакты', 'contacts'],
    ['Схема поступления', 'scheme'],
    ['Калькулятор ЕГЭ', 'calculator'],
    ['Формы обучения и требования', 'forms'])
back_kb = generate_kb('admission')


@router.callback_query(F.data.in_({'admission', 'contacts', 'forms'}))
async def get_info(callback: CallbackQuery):
    await callback.message.edit_text(messages[callback.data], parse_mode='HTML', disable_web_page_preview=True,
                                     reply_markup=kb if callback.data == 'admission' else back_kb)
