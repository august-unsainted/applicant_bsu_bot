from aiogram import Router, F
from aiogram.types import CallbackQuery

from utils.generate_kb import generate_kb
from utils.messages import messages

router = Router()

kb = generate_kb(
    'admission',
    ['Об этапах', 'olympiad_rounds'],
    ['Профили', 'olympiad_profiles'],
    ['Привилегии участников', 'olympiad_privileges'],
    ['Контакты оргкомитета', 'olympiad_contacts'],
    ['Документы', 'olympiad_documents'],
    ['Соорганизаторы', 'olympiad_organizers']
)
back_kb = generate_kb('olympiad')


@router.callback_query(F.data.startswith('olympiad'))
async def olympiad(callback: CallbackQuery):
    info_type = callback.data.replace('olympiad_', '')
    await callback.message.edit_text(messages[info_type], parse_mode='HTML',
                                     reply_markup=kb if info_type == 'olympiad' else back_kb)
