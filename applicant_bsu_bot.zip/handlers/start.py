from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart

from utils.images import images, create_image
from utils.generate_kb import generate_kb
from utils.messages import messages, keyboards, keyboards_text

router = Router()

# kb = generate_kb(
#     '',
#     ['Приемная кампания (2025 г.)', 'admission'],
#     ['Общежития', 'dormitories'],
#     ['Байкальская перспектива', 'olympiad'],
#     ['Пробный ЕГЭ', 'exams'],
#     ['Полезные ссылки', 'links'],
#     ['О разработчиках', 'developers']
# )
# back_kb = generate_kb('start')


def get_back(needle: str) -> str | None:
    for key, value in keyboards_text.items():
        for callback in value.keys():
            if callback == needle:
                return key


@router.message(CommandStart())
async def cmd_start(message: Message):
    # print(images['start']['input'],keyboards.get('start'))
    await message.answer_photo(photo=images['start']['fsinput'], caption=messages.get('start'), parse_mode='HTML', reply_markup=keyboards.get('start'))
    # await message.answer(messages['start'], parse_mode='HTML', reply_markup=kb)


@router.callback_query()
async def start(callback: CallbackQuery):
    kb = keyboards.get(callback.data) or generate_kb(get_back(callback.data))
    if images.get(callback.data):
        await callback.message.edit_media(images.get(callback.data).get('input'), reply_markup=kb,
                                          disable_web_page_preview=True)
    else:
        text = messages.get(callback.data)
        if callback.message.text:
            await callback.message.edit_text(text, reply_markup=kb)
        else:
            await callback.message.answer(text, parse_mode='HTML', reply_markup=kb)
            await callback.message.delete()


# @router.callback_query(F.data.in_({'start', 'exams', 'links', 'developers'}))
# async def exams(callback: CallbackQuery):
#     if images.get(callback.data):
#         await callback.message.edit_media(create_image(callback.data),
#                                           reply_markup=kb if callback.data == 'start' else back_kb,
#                                           disable_web_page_preview=True)
#     else:
#         await callback.message.answer(messages[callback.data], parse_mode='HTML', reply_markup=back_kb)
#         await callback.message.delete()
