from aiogram import Router, F
from aiogram.types import CallbackQuery

from utils.generate_kb import generate_kb
from utils.messages import messages

router = Router()

kb = generate_kb(
    'admission',
    ['Посещение БГУ', 'scheme_visit_bsu'],
    ['Через систему БГУ (онлайн)', 'scheme_bsu_system'],
    ['Через Госуслуги (онлайн)', 'scheme_epgu'],
)
back_kb = generate_kb('scheme')


@router.callback_query(F.data.startswith('scheme'))
async def scheme(callback: CallbackQuery):
    info_type = callback.data.replace('scheme_', '')
    await callback.message.answer(messages[info_type], parse_mode='HTML',
                                  reply_markup=kb if info_type == 'scheme' else back_kb)
    await callback.message.delete()
