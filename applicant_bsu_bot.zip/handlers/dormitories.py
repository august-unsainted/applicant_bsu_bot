from aiogram import Router, F
from aiogram.types import CallbackQuery

from utils.generate_kb import generate_kb
from utils.messages import messages

router = Router()

kb = generate_kb('start', ['Этапы заселения', 'stages'])
back_kb = generate_kb('dormitories')


@router.callback_query(F.data.in_({'dormitories', 'stages'}))
async def dormitories(callback: CallbackQuery):
    await callback.message.edit_text(
        messages[callback.data],
        parse_mode='HTML', reply_markup=kb if callback.data == 'dormitories' else back_kb
    )
