from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext

from utils.generate_kb import generate_kb, generate_calculator_kb
from utils.calculator import get_speciality
from utils.messages import messages

router = Router()

tip_kb = generate_kb('calculator', ['Шпаргалка', 'tip'])
back_kb = generate_kb('calculator')


@router.callback_query(F.data == 'calculator')
async def calculator(callback: CallbackQuery, state: FSMContext):
    if not (user_buttons_state := await state.get_data()):
        user_buttons_state = {f"subject_{i}": False for i in range(1, 12)}
        await state.update_data(buttons_state=user_buttons_state)
        user_buttons_state = {'buttons_state': user_buttons_state}
    await callback.message.edit_text('Выберите предметы:',
                                     reply_markup=generate_calculator_kb(user_buttons_state['buttons_state']))


@router.callback_query(F.data.startswith('subject'))
async def handle_callback(callback: CallbackQuery, state: FSMContext):
    user_data = await state.get_data()
    buttons_state = user_data.get('buttons_state', {f"subject_{i}": False for i in range(1, 12)})

    if callback.data == 'subject_next':
        speciality = get_speciality(user_data)
        if speciality and len(speciality) < 4096:
            await callback.message.edit_text(speciality, parse_mode='HTML', reply_markup=tip_kb)
        elif not speciality:
            await callback.answer(f'Нет специальностей 😢')
        else:
            await callback.answer(f'Выбрано слишком много предметов. Попробуйте еще раз')
    else:
        buttons_state[callback.data] = not buttons_state[callback.data]
        await state.update_data(buttons_state=buttons_state)
        await callback.message.edit_reply_markup(reply_markup=generate_calculator_kb(buttons_state))


@router.callback_query(F.data == 'tip')
async def get_tip(callback: CallbackQuery):
    await callback.message.edit_text(
        messages[callback.data],
        parse_mode='HTML',
        reply_markup=back_kb,
        disable_web_page_preview=True)
