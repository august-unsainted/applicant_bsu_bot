from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from utils.calculator import subjects


def generate_kb(back_callback: str = '', *buttons: list[str]) -> InlineKeyboardMarkup:
    kb = []
    for row in buttons:
        kb.append([InlineKeyboardButton(text=row[0], callback_data=row[1])])
    if back_callback:
        kb.append([InlineKeyboardButton(text='Назад ⬅️', callback_data=back_callback)])
    return InlineKeyboardMarkup(inline_keyboard=kb)


def generate_dict_kb(data: dict[str, dict[str]]) -> dict[str, InlineKeyboardMarkup]:
    kbs = {}
    for key, value in data.items():
        inline_kb = []
        for callback, text in value.items():
            inline_kb.append([InlineKeyboardButton(text=text, callback_data=callback)])
        kbs[key] = InlineKeyboardMarkup(inline_keyboard=inline_kb)
    return kbs


def generate_calculator_kb(buttons_state):
    keyboard = []
    arr = []
    for key, selected in buttons_state.items():
        text = f'✅ {subjects[key]}' if selected else subjects[key]
        arr.append(InlineKeyboardButton(text=text, callback_data=key))
    for i in range(0, 11, 2):
        if i != len(arr) - 1:
            keyboard.append([arr[i], arr[i + 1]])
        else:
            keyboard.append([arr[i]])
    keyboard.append([InlineKeyboardButton(text='Далее ➡️', callback_data='subject_next')])
    keyboard.append([InlineKeyboardButton(text='Назад ⬅️', callback_data='admission')])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)
