from pathlib import Path
import orjson
from aiogram.types import CallbackQuery, InlineKeyboardMarkup

from utils.generate_kb import generate_dict_kb

# from utils.images import images, create_image

data_dir = Path(__file__).parent.parent / 'data'
messages_path = data_dir / 'messages.json'
messages = orjson.loads(messages_path.read_bytes())

keyboards_path = data_dir / 'keyboards.json'
keyboards_text = orjson.loads(keyboards_path.read_bytes())
keyboards = generate_dict_kb(keyboards_text)

#
# async def handle_callback(callback: CallbackQuery, kb: InlineKeyboardMarkup, back_kb: InlineKeyboardMarkup):
#     if images.get(callback.data):
#         await callback.message.edit_media(create_image(callback.data),
#                                           reply_markup=kb if callback.data == 'start' else back_kb,
#                                           disable_web_page_preview=True)
#     else:
#         if callback.message.text:
#             await callback.message.answer(messages[callback.data], parse_mode='HTML', reply_markup=back_kb)
#             await callback.message.delete()
