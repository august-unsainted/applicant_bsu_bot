from pathlib import Path
import importlib.util as util
import orjson
from aiogram.types import InlineKeyboardMarkup


def sum_dicts(dict1: dict, dict2: dict[str]):
    for key, value in dict2.items():
        dict1[key] = value


project_dir = Path(__file__).parent.parent
handlers = project_dir / 'handlers'
kbs = {}
for root, _, files in handlers.walk():
    for file in files:
        if file.endswith('.py'):
            path = Path(root) / file
            name = file[:-3]
            spec = util.spec_from_file_location(name, str(path))
            module = util.module_from_spec(spec)
            spec.loader.exec_module(module)
            kb = getattr(module, 'kb', None)
            back_kb = getattr(module, 'back_kb', None)
            if kb:
                btns = {}
                for btn in kb.inline_keyboard:
                    btns[btn[0].callback_data] = btn[0].text
                    # btns.append([btn[0].text, btn[0].callback_data])
                kbs[name] = btns
            # print(file)
            # sum_dicts(kbs, dictionary)
json = orjson.dumps(kbs)
file = project_dir / 'data/keyboards.json'
file.write_bytes(json)
