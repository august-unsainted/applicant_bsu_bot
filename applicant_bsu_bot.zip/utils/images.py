from pathlib import Path
from aiogram.types import FSInputFile, InputMediaPhoto

from utils.messages import messages

project_dir = Path(__file__).parent.parent
src_dir = project_dir / 'data/images'
images = {}


def create_image(name: str, caption: str = '', file_id: str = '') -> InputMediaPhoto:
    return InputMediaPhoto(media=file_id or images.get(name), caption=caption or messages.get(name), parse_mode='HTML')


def create_input_file(name: str) -> FSInputFile:
    photo = FSInputFile(path=src_dir / f'{name}.jpg')
    return photo


def _load_images():
    for root, _, files in src_dir.walk():
        for file in files:
            file = file[:-4]
            fsinput = create_input_file(file)
            images[file] = {
                'fsinput': fsinput,
                'input': InputMediaPhoto(media=fsinput, caption=messages.get(file), parse_mode='HTML')
            }


_load_images()
